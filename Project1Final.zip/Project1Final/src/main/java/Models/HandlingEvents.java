/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author DELL
 */
public class HandlingEvents {
 
    
    int eventID;
    int nop;
    public String eType;
    public String eName;
    public String eventHandler;
    public String venue;
    
    
    public void EventDetails(int eventID, int nop, String eventName, String eType, String eventhandler, String venue){
        
      this.eventID=eventID;
      this.eName=eventName;
      this.eType=eType;
      this.nop=nop;
      this.eventHandler=eventhandler;
      this.venue=venue;
    }
}
